<section id="contact">
   <div class="container margintop65">
      <div class="row">
         <div class="col-lg-12">
            <div class="contact-content text-center">
               <h2 class="wow fadeInUp">Get In Touch</h2>
               <a href="contact-us.php" class="btn btn-readmore wow fadeInUp">Contact Us</a>
            </div>
         </div>
      </div>
      <div class="row text-center contactpadding">
         <div class="col-md-4 wow fadeInUp">
            <div class="contact-address">
               <i class="ion-ios-location-outline"></i>
               <h4>Kochi</h4>
               <p>1st floor, Thachil Tower<br>Pottakuzhi Jn, Kaloor, Kochi 682017.</p>
            </div>
         </div>
         <div class="col-md-4 wow fadeInUp" >
            <div class="contact-address middle" >
               <i class="ion-ios-location-outline"></i>
               <h4>Bangalore</h4>
               <p>#725, 21st Main Road,<br>2nd Phase JP Nagar, Banglore 560078.</p>
            </div>
         </div>
         <div class="col-md-4 wow fadeInUp">
            <div class="contact-address">
               <i class="ion-ios-location-outline"></i>
               <h4>Dublin</h4>
               <p>#12, Alderwood rise, Tallaght, Dublin 24<br>Ireland. Call +353 892 022 577</p>
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-lg-12">
            <div class="copyright wow fadeInUp text-center">
               <p class="wow fadeInUp" style="margin-top: 50px;margin-bottom: 10px">Follow Us:</p>
               <div class="social-links" style="margin-bottom: 10px">
                  <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                  <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                  <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                  <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
               </div>
               &copy; Copyright 2014<strong> Sparcs</strong>. All Rights Reserved
            </div>
         </div>
      </div>
   </div>
</section>